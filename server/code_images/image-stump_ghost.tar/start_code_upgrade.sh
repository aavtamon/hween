#!/bin/bash

$(dirname "$0")/code_upgrade.sh &
